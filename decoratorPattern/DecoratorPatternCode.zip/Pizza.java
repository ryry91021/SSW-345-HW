package DecoratorPartialJava;

public interface Pizza
{
    public String getDescription();
    public double getCost();
}
